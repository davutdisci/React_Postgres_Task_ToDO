import express, { Router } from 'express';
import TaskController from '../controllers/TaskController';

const router:Router = Router();
const taskController = new TaskController();

router.get('/get-tasks', taskController.get);
router.post('/add-task', taskController.post);
router.delete('/delete-task/:id', taskController.delete);
export default router;

