import pool from '../dbconfig/dbconnector';

class TaskController {

    public async get(req, res) {
        try {
            const client = await pool.connect();

            const sql = "SELECT * FROM tasks where _id IS NOT NULL";
            const { rows } = await client.query(sql);
            const tasks = rows;

            client.release();

            res.status(200).send(tasks);
        } catch (error) {
            res.status(400).send(error);
        }
    }


	public async delete(req, res) {
        	try {
				const client = await pool.connect();
	
				const sql = "DELETE FROM tasks WHERE _id=$1";
				await client.query(sql, [req.params.id]);
				client.release();
				
				const taskController = new TaskController();
				return taskController.get(null, res)
			} catch (error) {
				res.status(400).send(error);
			}
    }


	public async post(req, res) {
		try {
			const {name, description, status} = req.body;
			const client = await pool.connect();
			const sql = "INSERT INTO tasks (name, description, status) VALUES ($1, $2, $3)";
			await client.query(sql, [name, description, status]);

			client.release();
			const taskController = new TaskController();
			return taskController.get(null, res)
		} catch (error) {
			res.status(400).send(error);
		}

}
}

export default TaskController;