import axios, { AxiosResponse } from 'axios'

const baseUrl: string = 'http://localhost:4000'

export const getTasks= async (): Promise<AxiosResponse<any>> => {
  try {
    const tasks: AxiosResponse<any> = await axios.get(
      baseUrl + '/get-tasks'
    )
    return tasks
  } catch (error) {
    throw new Error(String(error))
  }
}

export const addTask = async (
  formData: ITask
): Promise<AxiosResponse<any>> => {
  try {
    const todo: Omit<ITask, '_id'> = {
      name: formData.name,
      description: formData.description,
      status: false,
    }
    const saveTodo: AxiosResponse<ApiDataType> = await axios.post(
      baseUrl + '/add-task',
      todo
    )
    return saveTodo
  } catch (error) {
    throw new Error(String(error))
  }
}

export const updateTask = async (
  todo: ITask
): Promise<AxiosResponse<ApiDataType>> => {
  try {
    const todoUpdate: Pick<ITask, 'status'> = {
      status: true,
    }
    const updatedTodo: AxiosResponse<any> = await axios.put(
      `${baseUrl}/edit-task/${todo._id}`,
      todoUpdate
    )
    return updatedTodo
  } catch (error) {
    throw new Error(String(error))
  }
}

export const deleteTask = async (
  _id: string
): Promise<AxiosResponse<any>> => {
  try {
    const deletedTodo: AxiosResponse<any> = await axios.delete(
      `${baseUrl}/delete-task/${_id}`
    )
    return deletedTodo
  } catch (error) {
    throw new Error(String(error))
  }
}
