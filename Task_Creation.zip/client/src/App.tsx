import React, { useEffect, useState } from 'react'
import TaskItem from './components/TaskItem'
import { getTasks, updateTask, deleteTask, addTask } from './apis/task-api'
import AddTask from './components/AddTask'

const App: React.FC = () => {
  let [tasks, setTasks] = useState<ITask[]>([])

  useEffect(() => {
    fetchTodos()
  }, [])

  const fetchTodos = (): void => {
    getTasks()
    .then((data) => setTasks(data.data as ITask[]))
    .catch((err: Error) => console.log(err))
  }

 const handleSaveTask = (e: React.FormEvent, formData: any): void => {
   e.preventDefault()
   addTask(formData)
   .then(({ status, data }) => {
    if (status !== 200) {
      throw new Error('Error! Todo not saved')
    }
    setTasks(data as ITask[])
  })
  .catch((err) => console.log(err))
}

  const handleUpdateTask = (todo: ITask): void => {
    updateTask(todo)
    .then(({ status, data }) => {
        if (status !== 200) {
          throw new Error('Error! Todo not updated')
        }
        setTasks(data as any)
      })
      .catch((err) => console.log(err))
  }

  const handleDeleteTask = (_id: string): void => {
    deleteTask(_id)
    .then(({ status, data }) => {
        if (status !== 200) {
          throw new Error('Error! Todo not deleted')
        }
        setTasks(data as ITask[])
      })
      .catch((err) => console.log(err))
  }

  return (
    <main className='App'>
      <h1>My Tasks</h1>
      <AddTask saveTodo= {handleSaveTask}/>
      {tasks.map((todo: ITask) => (
        <TaskItem
          key={todo._id}
          updateTodo={handleUpdateTask}
          deleteTodo={handleDeleteTask}
          todo={todo}
        />
      ))}
    </main>
  )
}

export default App
