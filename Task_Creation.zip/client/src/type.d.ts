interface ITask {
    _id: string
    name: string
    description: string
    status: boolean
}

type TodoProps = {
    todo: ITask
}

type ApiDataType = {
    message: string
    status: string
    todos: ITask[]
    todo?: ITask
  }
  